const socket = io();

let canvas;
let gui;

let colorSwatch, button, rSlider, gSlider, bSlider, sizeSlider;
let r = 255, g = 0, b = 100, bSize = 30;
let drawIsOn = false;

function setup() {
  canvas = createCanvas(windowWidth, windowHeight);
  canvas.parent("sketch-container");
  canvas.mousePressed(canvasMousePressed);
  canvas.touchStarted(canvasTouchStarted);

  gui = select("#gui-container");
  gui.addClass("open"); //forcing it open at the start, remove if you want it closed

  colorSwatch = createDiv("").parent(gui).addClass("color-swatch");

  rSlider = createSlider(0, 255, r).parent(gui).addClass("slider").input(handleSliderInputChange);
  gSlider = createSlider(0, 255, g).parent(gui).addClass("slider").input(handleSliderInputChange);
  bSlider = createSlider(0, 255, b).parent(gui).addClass("slider").input(handleSliderInputChange);
  sizeSlider = createSlider(1, 100, bSize).parent(gui).addClass("slider").input(handleSliderInputChange);

  button = createButton(">").parent(gui).addClass("button").mousePressed(handleButtonPress);

  handleSliderInputChange();

  background(255);
  noStroke();
}

function draw() {
  if (drawIsOn) {
    fill(r, g, b);
    circle(mouseX, mouseY, bSize);
  }
}

function canvasMousePressed() {
  drawIsOn = true;
}

function mouseReleased() {
  drawIsOn = false;
}

function mouseDragged() {
  if (!drawIsOn) return;

  const data = {
    xpos: mouseX / width,
    ypos: mouseY / height,
    userR: r,
    userG: g,
    userB: b,
    userS: bSize,
  };

  socket.emit("drawing", data);
}

function canvasTouchStarted() {
  drawIsOn = true;
}

function touchEnded() {
  drawIsOn = false;
}

function touchMoved() {
  if (!drawIsOn) return;

  const data = {
    xpos: mouseX / width,
    ypos: mouseY / height,
    userR: r,
    userG: g,
    userB: b,
    userS: bSize,
  };

  socket.emit("drawing", data);
}

function onDrawingEvent(data) {
  fill(data.userR, data.userG, data.userB);

  circle(data.xpos * width, data.ypos * height, data.userS); //slightly nicer on mobile
}

function handleButtonPress() {
  gui.toggleClass("open");
}

function handleSliderInputChange() {
  r = map(rSlider.value(), 0, rSlider.width, 0, 255);
  g = map(gSlider.value(), 0, gSlider.width, 0, 255);
  b = map(bSlider.value(), 0, bSlider.width, 0, 255);
  bSize = sizeSlider.value();

  colorSwatch.style("background-color", `rgb(${r},${g},${b})`);
}

socket.on("connect", () => {
  console.log(socket.id);
});

socket.on("disconnect", () => {
  console.log(socket.id);
});

socket.on("drawing", (data) => {
  console.log(data);
  onDrawingEvent(data);
});
